package com.soulland;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.LightningBoltEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;

public class SoulLogic {

    public static int need(int level) { return 20 + level * 15; }

    private static void msg(ServerPlayerEntity p, String s, boolean bar) {
        p.displayClientMessage(new StringTextComponent(s), bar);
    }

    public static void addXp(ServerPlayerEntity p, int amt) {
        if (SoulData.spirit(p) < 0) return;
        int lv = SoulData.level(p);
        int xp = SoulData.xp(p) + amt;
        while (lv < 100 && xp >= need(lv)) {
            xp -= need(lv);
            lv++;
            msg(p, "เลเวลอัป! ตอนนี้เลเวล " + lv, false);
        }
        SoulData.setLevel(p, lv);
        SoulData.setXp(p, xp);
        Net.sync(p);
    }

    public static boolean absorbRing(ServerPlayerEntity p, int ringType) {
        if (SoulData.spirit(p) < 0) { msg(p, "ต้องตื่นรู้วิญญาณยุทธ์ก่อน", true); return false; }
        int[] r = SoulData.rings(p);
        if (r.length >= 9) { msg(p, "มีวงแหวนครบ 9 วงแล้ว", true); return false; }
        int needLv = 10 * (r.length + 1);
        if (SoulData.level(p) < needLv) { msg(p, "ต้องเลเวล " + needLv + " ถึงจะดูดซับวงแหวนวงที่ " + (r.length + 1), true); return false; }
        int[] n = Arrays.copyOf(r, r.length + 1);
        n[r.length] = ringType;
        SoulData.setRings(p, n);
        msg(p, "ดูดซับวงแหวนวงที่ " + n.length + " สำเร็จ!", false);
        Net.sync(p);
        return true;
    }

    public static void toggle(ServerPlayerEntity p) {
        int sp = SoulData.spirit(p);
        if (sp < 0) { msg(p, "ยังไม่ตื่นรู้วิญญาณยุทธ์", true); return; }
        boolean on = !SoulData.active(p);
        SoulData.setActive(p, on);
        if (sp == 1) {
            if (on) {
                ItemStack st = new ItemStack(ModItems.HAMMER.get());
                st.getOrCreateTag().putBoolean("Unbreakable", true);
                if (!p.addItem(st)) p.drop(st, false);
            } else {
                for (int i = 0; i < p.inventory.getContainerSize(); i++) {
                    if (p.inventory.getItem(i).getItem() == ModItems.HAMMER.get()) p.inventory.setItem(i, ItemStack.EMPTY);
                }
            }
        }
        msg(p, Spirit.byId(sp).thName + (on ? " : เปิด" : " : ปิด"), true);
        Net.sync(p);
    }

    public static void toggleRings(ServerPlayerEntity p) {
        if (SoulData.spirit(p) < 0) { msg(p, "ยังไม่ตื่นรู้วิญญาณยุทธ์", true); return; }
        boolean on = !SoulData.ringsOn(p);
        SoulData.setRingsOn(p, on);
        msg(p, "วงแหวนวิญญาณ : " + (on ? "เปิด" : "ปิด"), true);
        Net.sync(p);
    }

    public static int unlocked(ServerPlayerEntity p) {
        int sp = SoulData.spirit(p);
        Spirit s = Spirit.byId(sp);
        if (s == null) return 0;
        int u = Math.min(SoulData.rings(p).length, s.skills.length);
        if (sp == 3) u = 1;
        return u;
    }

    public static void nextSkill(ServerPlayerEntity p) {
        int u = unlocked(p);
        if (u <= 0) { msg(p, "ยังไม่มีทักษะ", true); return; }
        SoulData.setSel(p, (SoulData.sel(p) + 1) % u);
        Net.sync(p);
    }

    private static List<LivingEntity> near(ServerPlayerEntity p, double r) {
        List<LivingEntity> l = new ArrayList<>();
        for (LivingEntity e : p.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r))) {
            if (e != p && e.isAlive()) l.add(e);
        }
        return l;
    }

    private static void fx(ServerWorld w, Entity e, IParticleData t, int n) {
        w.sendParticles(t, e.getX(), e.getY() + 1, e.getZ(), n, 1.5, 0.8, 1.5, 0.05);
    }

    private static void hit(ServerPlayerEntity p, LivingEntity e, float dmg, double push) {
        e.hurt(DamageSource.playerAttack(p), dmg);
        Vector3d d = e.position().subtract(p.position()).normalize().scale(push);
        e.push(d.x, 0.5, d.z);
        e.hurtMarked = true;
    }

    public static void cast(ServerPlayerEntity p) {
        int sp = SoulData.spirit(p);
        if (sp < 0) { msg(p, "ยังไม่ตื่นรู้วิญญาณยุทธ์", true); return; }
        if (!SoulData.active(p)) { msg(p, "เปิดวิญญาณยุทธ์ก่อน", true); return; }
        int sel = SoulData.sel(p);
        if (sel >= unlocked(p)) { msg(p, "ยังไม่ปลดล็อกทักษะนี้", true); return; }
        long now = p.level.getGameTime();
        if (now < SoulData.cd(p)) return;
        float cost = 8 + sel * 6;
        if (SoulData.mana(p) < cost) { msg(p, "มานาไม่พอ", true); return; }
        SoulData.setMana(p, SoulData.mana(p) - cost);
        SoulData.setCd(p, now + 30);

        ServerWorld w = (ServerWorld) p.level;
        switch (sp * 10 + sel) {
            // ต้นไม้เงินคราม
            case 0:
                for (LivingEntity e : near(p, 6)) { e.hurt(DamageSource.playerAttack(p), 2); e.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 80, 4)); }
                fx(w, p, ParticleTypes.HAPPY_VILLAGER, 50); break;
            case 1:
                p.heal(8); p.addEffect(new EffectInstance(Effects.REGENERATION, 100, 1));
                fx(w, p, ParticleTypes.HEART, 12); break;
            case 2:
                for (LivingEntity e : near(p, 5)) hit(p, e, 6, 1.0);
                fx(w, p, ParticleTypes.CRIT, 40); break;
            case 3:
                for (LivingEntity e : near(p, 8)) { hit(p, e, 8, 0.4); e.addEffect(new EffectInstance(Effects.POISON, 100, 1)); e.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 100, 3)); }
                fx(w, p, ParticleTypes.HAPPY_VILLAGER, 120); break;
            // ค้อนฮ่าวเทียน
            case 10:
                for (LivingEntity e : near(p, 5)) hit(p, e, 8, 1.4);
                fx(w, p, ParticleTypes.EXPLOSION, 6); break;
            case 11:
                p.addEffect(new EffectInstance(Effects.DAMAGE_BOOST, 300, 1));
                fx(w, p, ParticleTypes.FLAME, 40); break;
            case 12: {
                int c = 0;
                for (LivingEntity e : near(p, 10)) {
                    if (c++ >= 5) break;
                    LightningBoltEntity b = EntityType.LIGHTNING_BOLT.create(w);
                    if (b != null) { b.moveTo(e.getX(), e.getY(), e.getZ()); b.setVisualOnly(true); w.addFreshEntity(b); }
                    e.hurt(DamageSource.playerAttack(p), 10);
                }
                break;
            }
            case 13:
                p.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 200, 2));
                p.addEffect(new EffectInstance(Effects.ABSORPTION, 200, 2));
                fx(w, p, ParticleTypes.END_ROD, 40); break;
            // กระต่ายอรชร
            case 20: {
                Vector3d l = p.getLookAngle();
                p.setDeltaMovement(l.x * 1.8, 0.2, l.z * 1.8);
                p.hurtMarked = true;
                fx(w, p, ParticleTypes.CLOUD, 20); break;
            }
            case 21:
                p.addEffect(new EffectInstance(Effects.INVISIBILITY, 160, 0));
                p.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 160, 2));
                fx(w, p, ParticleTypes.POOF, 20); break;
            case 22:
                p.addEffect(new EffectInstance(Effects.JUMP, 200, 4));
                p.addEffect(new EffectInstance(Effects.SLOW_FALLING, 200, 0));
                fx(w, p, ParticleTypes.CLOUD, 20); break;
            case 23:
                for (LivingEntity e : near(p, 7)) hit(p, e, 9, 1.2);
                fx(w, p, ParticleTypes.SWEEP_ATTACK, 10); break;
            // ต้นหญ้า
            case 30:
                p.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 100, 0));
                fx(w, p, ParticleTypes.HAPPY_VILLAGER, 10); break;
            default: break;
        }
        Net.sync(p);
    }
}

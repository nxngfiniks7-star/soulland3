package com.soulland.mod;

import java.util.UUID;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.common.network.NetworkRegistry;

/** เก็บข้อมูลวิญญาณยุทธ์ใน persisted NBT ของผู้เล่น (ไม่หายตอนตาย) */
public class SoulData {
    private static final UUID HEALTH_ID = UUID.fromString("8c2d4a38-1f4b-4c10-9a6e-5d3c3e7a11b2");

    public static NBTTagCompound tag(EntityPlayer p) {
        NBTTagCompound d = p.getEntityData();
        if (!d.hasKey(EntityPlayer.PERSISTED_NBT_TAG, 10)) d.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        NBTTagCompound pt = d.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        if (!pt.hasKey("soulland", 10)) pt.setTag("soulland", new NBTTagCompound());
        return pt.getCompoundTag("soulland");
    }

    /** 0 = ยังไม่ปลุก, 1 = ค้อนฮ่าวเทียน, 2 = หญ้าสีเงินคราม, 3 = สองวิญญาณยุทธ์ */
    public static int getSoul(EntityPlayer p) { return tag(p).getInteger("soul"); }
    public static int getLevel(EntityPlayer p) { return tag(p).getInteger("level"); }
    public static int getExp(EntityPlayer p) { return tag(p).getInteger("exp"); }
    public static int getRings(EntityPlayer p) { return tag(p).getInteger("rings"); }
    public static int getMana(EntityPlayer p) { return tag(p).getInteger("mana"); }
    public static int getSelected(EntityPlayer p) { return tag(p).getInteger("selected"); }

    public static void setSoul(EntityPlayer p, int v) { tag(p).setInteger("soul", v); }
    public static void setLevel(EntityPlayer p, int v) { tag(p).setInteger("level", v); }
    public static void setExp(EntityPlayer p, int v) { tag(p).setInteger("exp", v); }
    public static void setRings(EntityPlayer p, int v) { tag(p).setInteger("rings", v); }
    public static void setMana(EntityPlayer p, int v) { tag(p).setInteger("mana", v); }
    public static void setSelected(EntityPlayer p, int v) { tag(p).setInteger("selected", v); }

    public static int maxMana(EntityPlayer p) { return 20 + getLevel(p) * 6; }
    public static int expNeeded(int level) { return 20 + level * 8; }
    /** เลเวลสูงสุดที่ไปได้ตามจำนวนวงแหวน (คอขวดทุก 10 เลเวล) */
    public static int levelCap(int rings) { return Math.min(99, 10 * (rings + 1)); }

    public static void awaken(EntityPlayerMP p, int soul) {
        setSoul(p, soul); setLevel(p, 1); setExp(p, 0); setRings(p, 0);
        setSelected(p, 0); setMana(p, maxMana(p));
        tag(p).setIntArray("tiers", new int[0]);
        tag(p).setBoolean("released", false);
        applyBonuses(p); sync(p); syncVisual(p);
    }

    public static void addExp(EntityPlayerMP p, int amt) {
        int lvl = getLevel(p);
        if (lvl <= 0) return;
        int cap = levelCap(getRings(p));
        if (lvl >= cap) return;
        int exp = getExp(p) + amt;
        boolean up = false;
        while (lvl < cap && exp >= expNeeded(lvl)) { exp -= expNeeded(lvl); lvl++; up = true; }
        if (lvl >= cap) exp = 0;
        setLevel(p, lvl); setExp(p, exp);
        if (up) {
            p.sendMessage(new TextComponentTranslation("msg.soulland.levelup", String.valueOf(lvl)));
            if (lvl >= cap && cap < 99) p.sendMessage(new TextComponentTranslation("msg.soulland.bottleneck"));
            applyBonuses(p);
        }
        sync(p);
    }

    public static void applyBonuses(EntityPlayerMP p) {
        IAttributeInstance inst = p.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
        inst.removeModifier(HEALTH_ID);
        if (getSoul(p) != 0) {
            inst.applyModifier(new AttributeModifier(HEALTH_ID, "soulland.health", getRings(p) * 4.0D + getLevel(p) / 5, 0));
        }
    }

    public static void sync(EntityPlayerMP p) {
        NetworkHandler.CHANNEL.sendTo(new PacketSync(getSoul(p), getLevel(p), getExp(p),
                getRings(p), getMana(p), getSelected(p)), p);
    }

    /** ระดับสีของวงแหวนแต่ละวง (0 ขาว ... 4 แดง) */
    public static int[] getTiers(EntityPlayer p) {
        int[] t = tag(p).getIntArray("tiers");
        int n = Math.min(9, getRings(p));
        int[] out = new int[n];
        for (int i = 0; i < n; i++) out[i] = i < t.length ? t[i] : 0;
        return out;
    }

    public static void addTier(EntityPlayer p, int tier) {
        int[] t = getTiers(p);
        int[] n = new int[t.length + 1];
        System.arraycopy(t, 0, n, 0, t.length);
        n[t.length] = tier;
        tag(p).setIntArray("tiers", n);
    }

    public static void syncVisual(EntityPlayerMP p) {
        PacketVisual v = new PacketVisual(p.getUniqueID(), getSoul(p), tag(p).getBoolean("released"), getTiers(p));
        NetworkHandler.CHANNEL.sendTo(v, p);
        NetworkHandler.CHANNEL.sendToAllAround(v, new NetworkRegistry.TargetPoint(p.dimension, p.posX, p.posY, p.posZ, 64));
    }
}

package com.soulland.mod;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

public class SoulSkills {
    public static final int HAMMER = 1, GRASS = 2;

    public static final class Skill {
        public final String key;
        public final int mask, ring, cost;
        Skill(String key, int mask, int ring, int cost) { this.key = key; this.mask = mask; this.ring = ring; this.cost = cost; }
    }

    public static final Skill[] ALL = {
        new Skill("entangle", GRASS, 1, 10),
        new Skill("smash", HAMMER, 1, 15),
        new Skill("heal", GRASS, 2, 20),
        new Skill("rage", HAMMER, 2, 20),
        new Skill("poison", GRASS, 3, 25),
        new Skill("quake", HAMMER, 3, 30),
        new Skill("whip", GRASS, 4, 25),
        new Skill("leap", HAMMER, 4, 35),
        new Skill("domain", GRASS, 5, 60),
        new Skill("wrath", HAMMER, 5, 60)
    };

    public static boolean available(int soul, int rings, int idx) {
        if (idx < 0 || idx >= ALL.length) return false;
        Skill s = ALL[idx];
        return (soul & s.mask) != 0 && rings >= s.ring;
    }

    public static int next(int soul, int rings, int from) {
        for (int i = 1; i <= ALL.length; i++) {
            int j = (from + i + ALL.length) % ALL.length;
            if (available(soul, rings, j)) return j;
        }
        return -1;
    }

    private static void msg(EntityPlayerMP p, String key) {
        p.sendStatusMessage(new TextComponentTranslation(key), true);
    }

    public static void cycle(EntityPlayerMP p) {
        int n = next(SoulData.getSoul(p), SoulData.getRings(p), SoulData.getSelected(p));
        if (n < 0) { msg(p, "msg.soulland.noskill"); return; }
        SoulData.setSelected(p, n);
        SoulData.sync(p);
    }

    public static void toggleRelease(EntityPlayerMP p) {
        if (SoulData.getSoul(p) == 0) { msg(p, "msg.soulland.needawaken"); return; }
        NBTTagCompound t = SoulData.tag(p);
        boolean r = !t.getBoolean("released");
        t.setBoolean("released", r);
        WorldServer ws = (WorldServer) p.world;
        if (r) {
            ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX, p.posY + 1.0, p.posZ, 40, 0.5, 0.8, 0.5, 0.05);
            ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0F, 1.3F);
        } else {
            ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 1.0F, 1.3F);
        }
        SoulData.syncVisual(p);
    }

    private static List<EntityLivingBase> nearby(EntityPlayerMP p, double r) {
        return p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(r),
                e -> e != p && e instanceof IMob && e.isEntityAlive());
    }

    private static void hit(EntityPlayerMP p, EntityLivingBase e, float dmg) {
        e.hurtResistantTime = 0;
        e.attackEntityFrom(DamageSource.causePlayerDamage(p), dmg);
    }

    private static void push(EntityPlayerMP p, EntityLivingBase e, float str) {
        e.knockBack(p, str, p.posX - e.posX, p.posZ - e.posZ);
    }

    private static void fx(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, int n, double spread) {
        ws.spawnParticle(t, p.posX, p.posY + 1.0, p.posZ, n, spread, 0.5, spread, 0.05);
    }

    public static void cast(EntityPlayerMP p) {
        int soul = SoulData.getSoul(p), rings = SoulData.getRings(p), idx = SoulData.getSelected(p);
        if (soul == 0) return;
        if (!available(soul, rings, idx)) { msg(p, "msg.soulland.noskill"); return; }
        Skill s = ALL[idx];
        long now = p.world.getTotalWorldTime();
        NBTTagCompound t = SoulData.tag(p);
        if (now < t.getLong("cd")) return;
        int mana = SoulData.getMana(p);
        if (mana < s.cost) { msg(p, "msg.soulland.nomana"); return; }
        SoulData.setMana(p, mana - s.cost);
        if (!t.getBoolean("released")) { t.setBoolean("released", true); SoulData.syncVisual(p); }
        t.setLong("cd", now + 15);

        float mult = p.getHeldItemMainhand().getItem() == ModItems.HAMMER ? 1.5F : 1.0F;
        WorldServer ws = (WorldServer) p.world;

        switch (s.key) {
            case "entangle":
                for (EntityLivingBase e : nearby(p, 6)) {
                    hit(p, e, 4);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 80, 4));
                }
                fx(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 40, 3);
                break;
            case "smash":
                for (EntityLivingBase e : nearby(p, 4)) { hit(p, e, 8 * mult); push(p, e, 1.5F); }
                fx(ws, EnumParticleTypes.EXPLOSION_LARGE, p, 3, 1.5);
                ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.2F);
                break;
            case "heal":
                p.heal(6);
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 160, 2));
                fx(ws, EnumParticleTypes.HEART, p, 10, 0.6);
                break;
            case "rage":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 600, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 600, 0));
                fx(ws, EnumParticleTypes.FLAME, p, 30, 0.8);
                break;
            case "poison":
                for (EntityLivingBase e : nearby(p, 7)) {
                    hit(p, e, 3);
                    e.addPotionEffect(new PotionEffect(MobEffects.POISON, 100, 1));
                }
                fx(ws, EnumParticleTypes.SLIME, p, 40, 3.5);
                break;
            case "quake":
                for (EntityLivingBase e : nearby(p, 6)) {
                    hit(p, e, 14 * mult);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 1));
                    e.motionY = 0.6; e.velocityChanged = true;
                }
                fx(ws, EnumParticleTypes.BLOCK_CRACK, p, 60, 3);
                ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.7F);
                break;
            case "whip": {
                Vec3d look = p.getLookVec();
                for (EntityLivingBase e : nearby(p, 10)) {
                    Vec3d to = new Vec3d(e.posX - p.posX, e.posY + e.height / 2 - (p.posY + p.getEyeHeight()), e.posZ - p.posZ);
                    if (to.length() < 10 && to.normalize().dotProduct(look) > 0.92) hit(p, e, 14);
                }
                for (int i = 1; i <= 10; i++)
                    ws.spawnParticle(EnumParticleTypes.CRIT, p.posX + look.x * i, p.posY + p.getEyeHeight() + look.y * i,
                            p.posZ + look.z * i, 3, 0.1, 0.1, 0.1, 0.0);
                break;
            }
            case "leap": {
                Vec3d look = p.getLookVec();
                p.motionX = look.x * 1.4; p.motionY = 0.9; p.motionZ = look.z * 1.4;
                p.velocityChanged = true;
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 100, 4));
                fx(ws, EnumParticleTypes.CLOUD, p, 20, 0.5);
                break;
            }
            case "domain":
                for (EntityLivingBase e : nearby(p, 10)) {
                    hit(p, e, 5);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 200, 1));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 200, 1));
                }
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 200, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 200, 0));
                fx(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 120, 5);
                break;
            case "wrath":
                for (EntityLivingBase e : nearby(p, 8)) { hit(p, e, 25 * mult); push(p, e, 2.0F); }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 2));
                fx(ws, EnumParticleTypes.EXPLOSION_HUGE, p, 3, 3);
                ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.6F);
                break;
            default: break;
        }
        SoulData.sync(p);
    }
}

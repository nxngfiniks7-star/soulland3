package com.soulland.mod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

/** เรนเดอร์วงแหวนวิญญาณและโมเดลวิญญาณยุทธ์บนตัวผู้เล่น */
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class SoulRender {
    private static final float[][] RING = {{1F, 1F, 1F}, {1F, 0.85F, 0.1F}, {0.7F, 0.25F, 0.95F}, {0.14F, 0.1F, 0.17F}, {1F, 0.1F, 0.1F}};
    private static final float[][] HALO = {{1F, 1F, 1F}, {1F, 0.8F, 0.2F}, {0.8F, 0.4F, 1F}, {0.55F, 0.0F, 0.75F}, {1F, 0.3F, 0.1F}};
    private static final float[] WOOD = {0.45F, 0.28F, 0.12F};
    private static final float[] STEEL = {0.62F, 0.66F, 0.78F};
    private static final float[] GLOW_BLUE = {0.3F, 0.6F, 1F};
    private static final float[] GRASS_BASE = {0.1F, 0.35F, 0.9F};
    private static final float[] GRASS_TIP = {0.75F, 0.92F, 1F};

    @SubscribeEvent
    public static void render(RenderPlayerEvent.Post e) {
        EntityPlayer p = e.getEntityPlayer();
        ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
        if (v == null || !v.released || v.soul == 0) return;

        float pt = e.getPartialRenderTick();
        float t = p.ticksExisted + pt;
        float yaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;

        GlStateManager.pushMatrix();
        GlStateManager.translate(e.getX(), e.getY(), e.getZ());
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();

        for (int pass = 0; pass < 2; pass++) {
            boolean glow = pass == 1;
            if (glow) {
                GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
                GlStateManager.depthMask(false);
            } else {
                GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
                GlStateManager.depthMask(true);
            }
            drawRings(v.tiers, t, glow);
            GlStateManager.pushMatrix();
            GlStateManager.rotate(-yaw, 0, 1, 0);
            if ((v.soul & 2) != 0) drawGrass(t, glow);
            if ((v.soul & 1) != 0) drawHammer(t, glow);
            GlStateManager.popMatrix();
        }

        GlStateManager.depthMask(true);
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.enableCull();
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.popMatrix();
    }

    // ---------- วงแหวน ----------
    private static void drawRings(int[] tiers, float t, boolean glow) {
        for (int i = 0; i < tiers.length; i++) {
            int tier = Math.max(0, Math.min(4, tiers[i]));
            float y = 0.12F + i * 0.19F;
            float r = 0.55F + 0.02F * (float) Math.sin(t * 0.1 + i);
            if (glow) {
                ring(y, r, 0.09F, 0.05F, HALO[tier], 0.28F);
                // ลูกแก้วเรืองแสงวิ่งรอบวง
                double ang = t * 0.08 * (i % 2 == 0 ? 1 : -1) + i;
                double px = Math.cos(ang) * r, pz = Math.sin(ang) * r;
                box(px - 0.04, y - 0.04, pz - 0.04, px + 0.04, y + 0.04, pz + 0.04, HALO[tier], 0.9F);
            } else {
                ring(y, r, 0.035F, 0.02F, RING[tier], 0.95F);
            }
        }
    }

    private static void ring(float y, float r, float w, float th, float[] c, float a) {
        Tessellator ts = Tessellator.getInstance();
        BufferBuilder b = ts.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        int n = 32;
        double ri = r - w, ro = r + w;
        for (int i = 0; i < n; i++) {
            double a0 = i * 2 * Math.PI / n, a1 = (i + 1) * 2 * Math.PI / n;
            double c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            for (int k = 0; k < 2; k++) {
                double yy = y + (k == 0 ? th : -th);
                vtx(b, ri * c0, yy, ri * s0, c, a); vtx(b, ro * c0, yy, ro * s0, c, a);
                vtx(b, ro * c1, yy, ro * s1, c, a); vtx(b, ri * c1, yy, ri * s1, c, a);
            }
            vtx(b, ro * c0, y - th, ro * s0, c, a); vtx(b, ro * c1, y - th, ro * s1, c, a);
            vtx(b, ro * c1, y + th, ro * s1, c, a); vtx(b, ro * c0, y + th, ro * s0, c, a);
            vtx(b, ri * c0, y - th, ri * s0, c, a); vtx(b, ri * c1, y - th, ri * s1, c, a);
            vtx(b, ri * c1, y + th, ri * s1, c, a); vtx(b, ri * c0, y + th, ri * s0, c, a);
        }
        ts.draw();
    }

    // ---------- ค้อนฮ่าวเทียน ----------
    private static void drawHammer(float t, boolean glow) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(-0.9F, 1.35F + 0.06F * (float) Math.sin(t * 0.07), -0.1F);
        GlStateManager.rotate(t * 1.5F, 0, 1, 0);
        GlStateManager.rotate(20F, 0, 0, 1);
        GlStateManager.scale(0.9F, 0.9F, 0.9F);
        if (glow) {
            box(-0.09, -0.65, -0.09, 0.09, 0.62, 0.09, GLOW_BLUE, 0.25F);
            box(-0.33, 0.30, -0.23, 0.33, 0.76, 0.23, GLOW_BLUE, 0.3F);
        } else {
            box(-0.04, -0.6, -0.04, 0.04, 0.6, 0.04, WOOD, 1F);
            box(-0.28, 0.35, -0.18, 0.28, 0.72, 0.18, STEEL, 1F);
            box(-0.30, 0.50, -0.20, 0.30, 0.56, 0.20, GLOW_BLUE, 1F);
            box(-0.06, -0.66, -0.06, 0.06, -0.55, 0.06, STEEL, 1F);
        }
        GlStateManager.popMatrix();
    }

    // ---------- หญ้าสีเงินคราม ----------
    private static void drawGrass(float t, boolean glow) {
        int count = 14;
        for (int k = 0; k < count; k++) {
            double a = k * 2 * Math.PI / count + t * 0.01;
            double rad = 0.4 + 0.3 * ((k * 37) % 5) / 5.0;
            float h = 0.55F + 0.55F * ((k * 53) % 7) / 7F;
            float tilt = 12F + 10F * (float) Math.sin(t * 0.08 + k);
            GlStateManager.pushMatrix();
            GlStateManager.translate(Math.cos(a) * rad, 0, Math.sin(a) * rad);
            GlStateManager.rotate((float) -Math.toDegrees(a), 0, 1, 0);
            GlStateManager.rotate(-tilt, 0, 0, 1);
            if (glow) {
                box(-0.06, 0, -0.06, 0.06, h, 0.06, GRASS_TIP, 0.18F);
            } else {
                box(-0.025, 0, -0.025, 0.025, h * 0.5F, 0.025, GRASS_BASE, 0.9F);
                box(-0.015, h * 0.5F, -0.015, 0.015, h, 0.015, GRASS_TIP, 0.95F);
            }
            GlStateManager.popMatrix();
        }
    }

    // ---------- ตัวช่วยวาด ----------
    private static void vtx(BufferBuilder b, double x, double y, double z, float[] c, float a) {
        b.pos(x, y, z).color(c[0], c[1], c[2], a).endVertex();
    }

    private static void box(double x1, double y1, double z1, double x2, double y2, double z2, float[] c, float a) {
        Tessellator ts = Tessellator.getInstance();
        BufferBuilder b = ts.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        vtx(b, x1, y1, z1, c, a); vtx(b, x2, y1, z1, c, a); vtx(b, x2, y1, z2, c, a); vtx(b, x1, y1, z2, c, a);
        vtx(b, x1, y2, z1, c, a); vtx(b, x1, y2, z2, c, a); vtx(b, x2, y2, z2, c, a); vtx(b, x2, y2, z1, c, a);
        vtx(b, x1, y1, z1, c, a); vtx(b, x1, y2, z1, c, a); vtx(b, x2, y2, z1, c, a); vtx(b, x2, y1, z1, c, a);
        vtx(b, x1, y1, z2, c, a); vtx(b, x2, y1, z2, c, a); vtx(b, x2, y2, z2, c, a); vtx(b, x1, y2, z2, c, a);
        vtx(b, x1, y1, z1, c, a); vtx(b, x1, y1, z2, c, a); vtx(b, x1, y2, z2, c, a); vtx(b, x1, y2, z1, c, a);
        vtx(b, x2, y1, z1, c, a); vtx(b, x2, y2, z1, c, a); vtx(b, x2, y2, z2, c, a); vtx(b, x2, y1, z2, c, a);
        ts.draw();
    }
}

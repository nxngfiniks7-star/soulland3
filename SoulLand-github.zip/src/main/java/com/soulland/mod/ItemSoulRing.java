package com.soulland.mod;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** วงแหวนวิญญาณ: 0 ขาว(10ปี) 1 เหลือง(100) 2 ม่วง(1000) 3 ดำ(10000) 4 แดง(100000) */
public class ItemSoulRing extends Item {
    public final int tier;

    public ItemSoulRing(int tier) { this.tier = tier; setMaxStackSize(16); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        ItemStack s = p.getHeldItem(h);
        if (w.isRemote) return new ActionResult<>(EnumActionResult.SUCCESS, s);
        EntityPlayerMP mp = (EntityPlayerMP) p;
        int rings = SoulData.getRings(mp);
        if (SoulData.getSoul(mp) == 0) { err(mp, "msg.soulland.needawaken"); return fail(s); }
        if (rings >= 9) { err(mp, "msg.soulland.maxrings"); return fail(s); }
        if (SoulData.getLevel(mp) < 10 * (rings + 1)) { err(mp, "msg.soulland.needlevel"); return fail(s); }

        int maxTier = Math.min(4, rings / 2 + 1);
        if (!p.capabilities.isCreativeMode) s.shrink(1);
        if (tier > maxTier) {
            mp.attackEntityFrom(DamageSource.MAGIC, 14.0F);
            mp.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 200, 0));
            mp.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 400, 1));
            mp.sendMessage(new TextComponentTranslation("msg.soulland.ringfail"));
            return new ActionResult<>(EnumActionResult.SUCCESS, s);
        }
        SoulData.addTier(mp, tier);
        SoulData.setRings(mp, rings + 1);
        SoulData.applyBonuses(mp);
        SoulData.setMana(mp, SoulData.maxMana(mp));
        int n = SoulSkills.next(SoulData.getSoul(mp), rings + 1, SoulData.getSelected(mp));
        if (n >= 0 && !SoulSkills.available(SoulData.getSoul(mp), rings, SoulData.getSelected(mp))) SoulData.setSelected(mp, n);
        SoulData.sync(mp);
        SoulData.syncVisual(mp);
        mp.sendMessage(new TextComponentTranslation("msg.soulland.ringok", String.valueOf(rings + 1)));
        return new ActionResult<>(EnumActionResult.SUCCESS, s);
    }

    private static void err(EntityPlayerMP p, String k) { p.sendStatusMessage(new TextComponentTranslation(k), true); }

    private static ActionResult<ItemStack> fail(ItemStack s) { return new ActionResult<>(EnumActionResult.FAIL, s); }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World w, List<String> tip, ITooltipFlag f) {
        tip.add(I18n.format("tooltip.soulland.age." + tier));
        tip.add(I18n.format("tooltip.soulland.ring"));
    }
}

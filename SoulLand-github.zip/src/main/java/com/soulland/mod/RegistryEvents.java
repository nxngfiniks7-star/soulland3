package com.soulland.mod;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class RegistryEvents {
    @SubscribeEvent
    public static void items(RegistryEvent.Register<Item> e) {
        for (Item i : ModItems.ALL) e.getRegistry().register(i);
    }
}
